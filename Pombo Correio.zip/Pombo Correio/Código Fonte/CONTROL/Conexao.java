package com.pombocorreio.thyago.pombocorreio.CONTROL;

import android.database.sqlite.SQLiteDatabase;

/**
 * Created by thyago on 16/10/15.
 */

public class Conexao {

    private Criar_BD criar_bd;
    private static  SQLiteDatabase dbLer;          //Escrever
    private static SQLiteDatabase dbConsultar;  //Ler

    public Conexao(){
    }

    public static SQLiteDatabase getDbConsultar() {
        return dbConsultar;
    }

    public static void setDbConsultar(SQLiteDatabase dbConsultar) {
        Conexao.dbConsultar = dbConsultar;
    }

    public SQLiteDatabase ObterdbLer() {
        return dbLer;
    }

    public void setDb(SQLiteDatabase dbLer) {
        this.dbLer = dbLer;
    }

    public void FecharConexao(){
        this.criar_bd.close();
    }



}
