package com.pombocorreio.thyago.pombocorreio.CONTROL;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

/**
 * Created by thyago on 16/10/15.
 */

public class Control {
    private Conexao conexao;

    public Control(){
        conexao = new Conexao();
    }


    public void inserir(String data, int cod_msg){

        System.out.println("Data " + data);
        System.out.println("Cod_Msg " + cod_msg);

        SQLiteDatabase db = conexao.ObterdbLer();
        ContentValues cv = new ContentValues();
        cv.put("data", data);
        cv.put("cod_msg", cod_msg);

        long resultado = db.insert("CARTAS",null,cv);

        if(resultado != -1){
            System.out.println("Inserido com suecesso !");
        } else{
            System.out.println("Erro ao inserir no BD !!!");
        }
    }

  /*  public void SelecionarCartas(){

        SQLiteDatabase db = conexao.getDbConsultar();
        Cursor cursor = db.rawQuery("SELECT * FROM CARTAS", null);
        cursor.moveToFirst();
        ArrayList<String> cartas = new ArrayList();
        cartas.clear();
        int id;
        String data;
        int cod;
        for(int i = 0; i < cursor.getCount(); i++){
            id = cursor.getInt(0);
            data = cursor.getString(1);
            cod = cursor.getInt(2);
            System.out.println("ID " + id);
            System.out.println("Data " + data);
            System.out.println("Cod " + cod);
            System.out.println("\n");
        }

        System.out.println("Select" + cursor.getCount());
//        for(int i = 0; i < cartas.size(); i++){
//            //System.out.println("\n");
//            System.out.println(cartas.get(i));
//        }


    }*/

    public int Seleciona_Num_Cartas(){
        int x;
        SQLiteDatabase db = conexao.getDbConsultar();
        Cursor cursor = db.rawQuery("SELECT numero_carta FROM NUMCARTA", null);
        cursor.moveToFirst();
        x = cursor.getInt(0);
        System.out.println("Seleciona_Num_Cartas " + x);
        return x;
    }

    public ArrayList Seleciona_Registro_Entrada(){
        String data;

        SQLiteDatabase db = conexao.getDbConsultar();
        Cursor cursor = db.rawQuery("SELECT data FROM CARTAS WHERE cod_msg = ?", new String[]{"1"});
        cursor.moveToFirst();

        ArrayList<String> Array_Entrada = new ArrayList<>();
        for(int i = 0; i < cursor.getCount(); i++){
            data = String.valueOf(cursor.getString(0));
            Array_Entrada.add(i, data);
            //System.out.println(data);
            cursor.moveToNext();
        }
        //System.out.println("Seleciona_Registro_Entrada ");
        return Array_Entrada;
    }

    public ArrayList Seleciona_Registro_Saida(){
        String data;

        SQLiteDatabase db = conexao.getDbConsultar();
        Cursor cursor = db.rawQuery("SELECT data FROM CARTAS WHERE cod_msg = ?", new String[]{"0"});
        cursor.moveToFirst();

        ArrayList<String> Array_Entrada = new ArrayList<>();
        for(int i = 0; i < cursor.getCount(); i++){
            data = String.valueOf(cursor.getString(0));
            Array_Entrada.add(i, data);
            //System.out.println(data);
            cursor.moveToNext();
        }
        //System.out.println("Seleciona_Registro_Entrada ");
        return Array_Entrada;
    }

    public void Atualiza(int num_cartas){
        SQLiteDatabase db = conexao.ObterdbLer();
        ContentValues cv = new ContentValues();
        cv.put("numero_carta", num_cartas);
        long resultado = db.update("NUMCARTA",cv,"_id = ?", new String[]{"1"});

        if(resultado != -1){
            System.out.println("Atualizado com suecesso !");
        } else{
            System.out.println("Erro ao Atualizar no BD !!!");
        }
    }


    /*public void Insere_NumCarta(){
        SQLiteDatabase db = conexao.ObterdbLer();
        ContentValues cv = new ContentValues();
        cv.put("numero_carta", 0);
        long resultado = db.insert("NUMCARTA", null, cv);

        if(resultado != -1){
            //System.out.println("Atualizado com suecesso !");
        } else{
            //System.out.println("Erro ao Atualizar no BD !!!");
        }
    }
*/
//    public void Deletar(){
//        SQLiteDatabase db = conexao.ObterdbLer();
//        db.delete("CARTAS",null,null);
//        //db.close();
//    }



}
