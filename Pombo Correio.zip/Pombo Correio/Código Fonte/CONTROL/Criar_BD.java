package com.pombocorreio.thyago.pombocorreio.CONTROL;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by thyago on 16/10/15.
 */

public class Criar_BD extends SQLiteOpenHelper {

    private static final String BD = "PC";
    private static int VERSAO = 1;
    
    public Criar_BD(Context context){
        super(context, BD, null, VERSAO);
    }

    //Cria a Estrutura do BD
    @Override
    public void onCreate(SQLiteDatabase db) {
         db.execSQL("CREATE TABLE CARTAS(" +
                 "_id       INTEGER         PRIMARY KEY     AUTOINCREMENT, " +
                 "data      VARCHAR(30)     NOT NULL, " +
                 "cod_msg   INTEGER         NOT NULL);");

        db.execSQL("CREATE TABLE NUMCARTA(" +
                 "_id       INTEGER         PRIMARY KEY     AUTOINCREMENT," +
                 "numero_carta  INTEGER);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
}
