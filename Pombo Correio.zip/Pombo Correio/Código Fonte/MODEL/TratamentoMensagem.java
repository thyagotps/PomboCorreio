package com.pombocorreio.thyago.pombocorreio.MODEL;

import android.content.Context;
import com.pombocorreio.thyago.pombocorreio.CONTROL.Control;
import com.pombocorreio.thyago.pombocorreio.VIEW.MainActivity;

/**
 * Created by thyago on 13/10/15.
 */
public class TratamentoMensagem {
    private String Mensagem;
    private Carta carta;
    private MainActivity context;
    private Control control;

    public TratamentoMensagem(Context context){
        this.context = (MainActivity) context;
        control = new Control();
        carta = new Carta();
    }

    public String getMensagem() {
        return Mensagem;
    }

    public void setMensagem(String mensagem) {
        Mensagem = mensagem;
    }

    public int Verifica_Mensagem(){
        int x = 3;

        //Carta Retirada
        if(Mensagem.equals("0")){
            x = 0;
            System.out.println("VerificaMensagem 0");
        }

        //Novas Cartas
        if(Mensagem.equals("1")){
            x = 1;
            System.out.println("VerificaMensagem 1");
        }

        return x;
    }

    public void Insere_Carta(){
        carta.setData(carta.data());
        carta.setCod_msg(Verifica_Mensagem());

        System.out.println("Está inserindo esta porra " + carta.getData() + carta.getCod_msg());

        control.inserir(carta.getData(), carta.getCod_msg());

        Incrementa(Verifica_Mensagem());

        updateUI(String.valueOf("Número de cartas: " + control.Seleciona_Num_Cartas()));
    }

    public void Incrementa(int cod_msg){
        if(cod_msg == 1){
            Atualiza(Seleciona_Num_Cartas() + 1);
        } else{
            Atualiza(0);
        }
    }

    public void Atualiza(int num_cartas){
        control.Atualiza(num_cartas);
    }

    public int Seleciona_Num_Cartas(){
        int x = control.Seleciona_Num_Cartas();
        return x;
    }

    public void updateUI(final String str){
        context.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                context.setTextView_NumCartas(str);
            }
        });
    }

}
