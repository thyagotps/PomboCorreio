package com.pombocorreio.thyago.pombocorreio.MODEL;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * Created by thyago on 19/10/15.
 */
public class Carta {

    private int cod_msg;
    private String data;
    private int NumCartas;

    public int getNumCartas() {
        return NumCartas;
    }

    public void setNumCartas(int numCartas) {
        if(numCartas == 0 || numCartas == 1){
            NumCartas = numCartas;
        } else{
            System.out.println("Erro ! Classe Carta.");
        }
    }

    public int getCod_msg() {
        return cod_msg;
    }

    public void setCod_msg(int cod_msg) {
        this.cod_msg = cod_msg;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String data(){
        Calendar calendar = new GregorianCalendar();
        Date date = calendar.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy hh:mm");
        return sdf.format(date);
    }
}
