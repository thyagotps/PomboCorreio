package com.pombocorreio.thyago.pombocorreio.Bluetooth;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;

/**
 * Created by thyago on 21/10/15.
 */
public class VerificaBluetooth {
    private BluetoothAdapter MeuBluetoothAdapter;
    private Activity activity;

    //Construtor
    public VerificaBluetooth(Activity activity){
        this.activity = activity;
    }


    //Métodos
    public void Verifica(){
        MeuBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if(!MeuBluetoothAdapter.isEnabled()){
            System.out.println("Bluetooth Desligado !");
            Intent EnableBluetoothIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            activity.startActivityForResult(EnableBluetoothIntent, 1);
            try {
                Thread.currentThread().sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }else{
            System.out.println("Bluetooth Ligado !");
        }
    }


}
