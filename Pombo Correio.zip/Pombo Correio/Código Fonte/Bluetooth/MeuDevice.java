package com.pombocorreio.thyago.pombocorreio.Bluetooth;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;

import java.util.Set;

/**
 * Created by thyago on 21/10/15.
 */

public class MeuDevice extends Thread {
    private static BluetoothDevice MeuDevice;
    private BluetoothAdapter MeuBluetoothAdapter;

    //Getter and Setter
    public static BluetoothDevice getMeuDevice() {
        return MeuDevice;
    }

    public static void setMeuDevice(BluetoothDevice meuDevice) {
        MeuDevice = meuDevice;
    }

    //Construtor
    public MeuDevice() {
        MeuDevice = null;
        MeuBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    }

    //Métodos
    public void run() {
        //Dispositivos_Pareados
        Set<BluetoothDevice> pairedDevices = MeuBluetoothAdapter.getBondedDevices();
        if (pairedDevices.size() > 0) {
            for (BluetoothDevice device : pairedDevices) {
                if (device.getName().toString().equals("HC-06")) {
                    this.MeuDevice = device;
                }
            }
        }
    }

} //Fim
