package com.pombocorreio.thyago.pombocorreio.Bluetooth;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import java.io.IOException;
import java.util.UUID;

/**
 * Created by thyago on 21/10/15.
 */
public class ConectaDevices extends Thread {

    private static BluetoothSocket MeuSocket;
    private BluetoothSocket temp;
    private BluetoothDevice BTMeuDevice;
    private final BluetoothAdapter MeuBluetoothAdapter;
    private final UUID MY_UUID;


    //Getter and Setter
    public static BluetoothSocket getMeuSocket() {
        return MeuSocket;
    }

    public static void setMeuSocket(BluetoothSocket meuSocket) {
        MeuSocket = meuSocket;
    }

    //Construtor
    public ConectaDevices(BluetoothDevice md){
        BTMeuDevice = md;
        MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");
        MeuBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        temp = null;

        try{
            temp = BTMeuDevice.createRfcommSocketToServiceRecord(MY_UUID);
        } catch (IOException e) {
            e.printStackTrace();
        }

        MeuSocket = temp;
    }

    //Métodos
    public void run(){
        MeuBluetoothAdapter.cancelDiscovery();
        try{
            MeuSocket.connect();
        } catch (IOException e) {
            e.printStackTrace();
            try{
                MeuSocket.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return;
        }

    }

    public void cancel() throws IOException {
        MeuSocket.close();
    }
}
