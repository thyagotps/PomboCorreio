package com.pombocorreio.thyago.pombocorreio.Bluetooth;

import android.bluetooth.BluetoothSocket;
import android.content.Context;
import com.pombocorreio.thyago.pombocorreio.MODEL.TratamentoMensagem;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by thyago on 21/10/15.
 */
public class GerenciarConexao extends Thread {

    private final BluetoothSocket bs;
    private final InputStream iss;
    private TratamentoMensagem tratamentoMensagem;
    private byte[] buffer;
    private int bytes;
    private Context context;

    //Construtor
    public GerenciarConexao(BluetoothSocket bs, Context context){
        this.context = context;
        tratamentoMensagem = new TratamentoMensagem(this.context);
        this.bs = bs;
        buffer = new byte[1024];
        InputStream tmp = null;

        bytes = 0;

        try{
            tmp = this.bs.getInputStream();
        } catch(IOException e){
            System.out.println("Erro Construtor GerenciarConexao");
        }

        iss = tmp;
    }

    //Métodos
    public String RecebeInfo(){
        InputStreamReader isr = new InputStreamReader(iss);

        BufferedReader br = new BufferedReader(isr);

        String s = null;
        try {
            s = br.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }

        while (s != null) {

            try {
                s = br.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
            //System.out.println("Info Recebidos");
            //System.out.println(s);
            tratamentoMensagem.setMensagem(s);
            tratamentoMensagem.Insere_Carta();
            //tratamentoMensagem.VerificarMensagem();
        }
        return s;
    }

    public void run(){
        RecebeInfo();
    }
}
