package com.pombocorreio.thyago.pombocorreio.VIEW;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import com.pombocorreio.thyago.pombocorreio.Bluetooth.ConectaDevices;
import com.pombocorreio.thyago.pombocorreio.Bluetooth.GerenciarConexao;
import com.pombocorreio.thyago.pombocorreio.Bluetooth.MeuDevice;
import com.pombocorreio.thyago.pombocorreio.Bluetooth.VerificaBluetooth;
import com.pombocorreio.thyago.pombocorreio.CONTROL.Conexao;
import com.pombocorreio.thyago.pombocorreio.CONTROL.Control;
import com.pombocorreio.thyago.pombocorreio.CONTROL.Criar_BD;
import com.pombocorreio.thyago.pombocorreio.R;

public class MainActivity extends ActionBarActivity {

    //Atributos
    private VerificaBluetooth verificaBluetooth;
    private MeuDevice meuDevice;
    private ConectaDevices conectaDevices;
    private GerenciarConexao gerenciarConexao;
    private Criar_BD criar_bd;
    private Conexao conexao;
    private Control control;
    public TextView textView_NumCartas;

    public TextView getTextView_NumCartas() {
        return textView_NumCartas;
    }

    public void setTextView_NumCartas(String NumCartas) {
        this.textView_NumCartas.setText(NumCartas);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.textView_NumCartas = (TextView) findViewById(R.id.StatusCartas);

        criar_bd = new Criar_BD(this);
        SQLiteDatabase db = criar_bd.getWritableDatabase();
        conexao = new Conexao();
        conexao.setDb(db);
        SQLiteDatabase dbConsultar = criar_bd.getReadableDatabase();
        conexao.setDbConsultar(dbConsultar);




        Bluetooth();
        control = new Control();
        setTextView_NumCartas(String.valueOf("Número de cartas: " + control.Seleciona_Num_Cartas()));

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void onClickMail(View view){

        //control.SelecionarCartas();
        //control.Seleciona_Num_Cartas();
        startActivity(new Intent(this, RegistroTab.class));

    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected  void onStart() {
        super.onStart();
    }

    public void Bluetooth(){
        verificaBluetooth = new VerificaBluetooth(this);
        verificaBluetooth.Verifica();

        meuDevice = new MeuDevice();
        meuDevice.start();
        try {
            meuDevice.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        conectaDevices = new ConectaDevices(meuDevice.getMeuDevice());
        try {
            conectaDevices.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        conectaDevices.start();

        gerenciarConexao = new GerenciarConexao(conectaDevices.getMeuSocket(), this);
        try {
            gerenciarConexao.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        gerenciarConexao.start();
    }

}

