package com.pombocorreio.thyago.pombocorreio.VIEW;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import com.pombocorreio.thyago.pombocorreio.CONTROL.Control;
import com.pombocorreio.thyago.pombocorreio.R;

/**
 * Created by thyago on 28/10/15.
 */
public class RegistroTab extends Activity {

    private ArrayAdapter<String> adapter;
    private Control control;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registro);

        control = new Control();
        listView = (ListView) findViewById(R.id.listView_Registro);
    }

    public void onClick_Entrada(View view){
        listView.setAdapter(null);
        adapter = new ArrayAdapter(this,R.layout.lista_registro,R.id.textView_lista_registro ,control.Seleciona_Registro_Entrada());
        listView.setAdapter(adapter);
    }

    public void onClick_Saida(View view){
        listView.setAdapter(null);
        adapter = new ArrayAdapter(this,R.layout.lista_registro,R.id.textView_lista_registro ,control.Seleciona_Registro_Saida());
        listView.setAdapter(adapter);
    }
}

